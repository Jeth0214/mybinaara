import{b as a,c as b}from"./chunk-KHFEQKET.js";import"./chunk-EQDQRRRY.js";export{a as GESTURE_CONTROLLER,b as createGesture};
